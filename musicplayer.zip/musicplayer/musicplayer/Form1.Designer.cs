﻿namespace musicplayer
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Do = new System.Windows.Forms.Button();
            this.Re = new System.Windows.Forms.Button();
            this.Mi = new System.Windows.Forms.Button();
            this.Fa = new System.Windows.Forms.Button();
            this.So = new System.Windows.Forms.Button();
            this.La = new System.Windows.Forms.Button();
            this.Si = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.ChangeColor = new System.Windows.Forms.Button();
            this.StopAuto = new System.Windows.Forms.Button();
            this.restart = new System.Windows.Forms.Button();
            this.Choose = new System.Windows.Forms.ComboBox();
            this.Autoplay = new System.Windows.Forms.Button();
            this.Si_key = new System.Windows.Forms.Label();
            this.La_key = new System.Windows.Forms.Label();
            this.So_key = new System.Windows.Forms.Label();
            this.Fa_key = new System.Windows.Forms.Label();
            this.Mi_key = new System.Windows.Forms.Label();
            this.Re_key = new System.Windows.Forms.Label();
            this.Do_key = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Do
            // 
            this.Do.Location = new System.Drawing.Point(245, 449);
            this.Do.Name = "Do";
            this.Do.Size = new System.Drawing.Size(75, 23);
            this.Do.TabIndex = 0;
            this.Do.Text = "Do";
            this.Do.UseVisualStyleBackColor = true;
            this.Do.Click += new System.EventHandler(this.Do_Click);
            // 
            // Re
            // 
            this.Re.Location = new System.Drawing.Point(320, 449);
            this.Re.Name = "Re";
            this.Re.Size = new System.Drawing.Size(75, 23);
            this.Re.TabIndex = 1;
            this.Re.Text = "Re";
            this.Re.UseVisualStyleBackColor = true;
            this.Re.Click += new System.EventHandler(this.Re_Click);
            // 
            // Mi
            // 
            this.Mi.Location = new System.Drawing.Point(395, 449);
            this.Mi.Name = "Mi";
            this.Mi.Size = new System.Drawing.Size(75, 23);
            this.Mi.TabIndex = 2;
            this.Mi.Text = "Mi";
            this.Mi.UseVisualStyleBackColor = true;
            this.Mi.Click += new System.EventHandler(this.Mi_Click);
            // 
            // Fa
            // 
            this.Fa.Location = new System.Drawing.Point(470, 449);
            this.Fa.Name = "Fa";
            this.Fa.Size = new System.Drawing.Size(75, 23);
            this.Fa.TabIndex = 3;
            this.Fa.Text = "Fa";
            this.Fa.UseVisualStyleBackColor = true;
            this.Fa.Click += new System.EventHandler(this.Fa_Click);
            // 
            // So
            // 
            this.So.Location = new System.Drawing.Point(545, 449);
            this.So.Name = "So";
            this.So.Size = new System.Drawing.Size(75, 23);
            this.So.TabIndex = 4;
            this.So.Text = "So";
            this.So.UseVisualStyleBackColor = true;
            this.So.Click += new System.EventHandler(this.So_Click);
            // 
            // La
            // 
            this.La.Location = new System.Drawing.Point(620, 449);
            this.La.Name = "La";
            this.La.Size = new System.Drawing.Size(75, 23);
            this.La.TabIndex = 5;
            this.La.Text = "La";
            this.La.UseVisualStyleBackColor = true;
            this.La.Click += new System.EventHandler(this.La_Click);
            // 
            // Si
            // 
            this.Si.Location = new System.Drawing.Point(695, 449);
            this.Si.Name = "Si";
            this.Si.Size = new System.Drawing.Size(75, 23);
            this.Si.TabIndex = 6;
            this.Si.Text = "Si";
            this.Si.UseVisualStyleBackColor = true;
            this.Si.Click += new System.EventHandler(this.Si_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 10;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // ChangeColor
            // 
            this.ChangeColor.Location = new System.Drawing.Point(32, 155);
            this.ChangeColor.Name = "ChangeColor";
            this.ChangeColor.Size = new System.Drawing.Size(89, 23);
            this.ChangeColor.TabIndex = 7;
            this.ChangeColor.Text = "改變顏色";
            this.ChangeColor.UseVisualStyleBackColor = true;
            this.ChangeColor.Click += new System.EventHandler(this.ChangeColor_Click);
            // 
            // StopAuto
            // 
            this.StopAuto.Location = new System.Drawing.Point(32, 97);
            this.StopAuto.Name = "StopAuto";
            this.StopAuto.Size = new System.Drawing.Size(89, 23);
            this.StopAuto.TabIndex = 9;
            this.StopAuto.Text = "停止自動撥放";
            this.StopAuto.UseVisualStyleBackColor = true;
            this.StopAuto.Click += new System.EventHandler(this.StopAuto_Click);
            // 
            // restart
            // 
            this.restart.Location = new System.Drawing.Point(32, 126);
            this.restart.Name = "restart";
            this.restart.Size = new System.Drawing.Size(89, 23);
            this.restart.TabIndex = 10;
            this.restart.Text = "restart";
            this.restart.UseVisualStyleBackColor = true;
            this.restart.Click += new System.EventHandler(this.restart_Click);
            // 
            // Choose
            // 
            this.Choose.FormattingEnabled = true;
            this.Choose.Location = new System.Drawing.Point(32, 44);
            this.Choose.Name = "Choose";
            this.Choose.Size = new System.Drawing.Size(121, 20);
            this.Choose.TabIndex = 11;
            this.Choose.SelectedIndexChanged += new System.EventHandler(this.Choose_SelectedIndexChanged);
            // 
            // Autoplay
            // 
            this.Autoplay.Location = new System.Drawing.Point(32, 68);
            this.Autoplay.Name = "Autoplay";
            this.Autoplay.Size = new System.Drawing.Size(89, 23);
            this.Autoplay.TabIndex = 12;
            this.Autoplay.Text = "自動撥放";
            this.Autoplay.UseVisualStyleBackColor = true;
            this.Autoplay.Click += new System.EventHandler(this.Autoplay_Click);
            // 
            // Si_key
            // 
            this.Si_key.AutoSize = true;
            this.Si_key.Font = new System.Drawing.Font("新細明體", 12F);
            this.Si_key.Location = new System.Drawing.Point(753, 495);
            this.Si_key.Name = "Si_key";
            this.Si_key.Size = new System.Drawing.Size(13, 16);
            this.Si_key.TabIndex = 20;
            this.Si_key.Text = "J";
            // 
            // La_key
            // 
            this.La_key.AutoSize = true;
            this.La_key.Font = new System.Drawing.Font("新細明體", 12F);
            this.La_key.Location = new System.Drawing.Point(669, 495);
            this.La_key.Name = "La_key";
            this.La_key.Size = new System.Drawing.Size(18, 16);
            this.La_key.TabIndex = 19;
            this.La_key.Text = "H";
            // 
            // So_key
            // 
            this.So_key.AutoSize = true;
            this.So_key.Font = new System.Drawing.Font("新細明體", 12F);
            this.So_key.Location = new System.Drawing.Point(588, 495);
            this.So_key.Name = "So_key";
            this.So_key.Size = new System.Drawing.Size(18, 16);
            this.So_key.TabIndex = 18;
            this.So_key.Text = "G";
            // 
            // Fa_key
            // 
            this.Fa_key.AutoSize = true;
            this.Fa_key.Font = new System.Drawing.Font("新細明體", 12F);
            this.Fa_key.Location = new System.Drawing.Point(510, 495);
            this.Fa_key.Name = "Fa_key";
            this.Fa_key.Size = new System.Drawing.Size(15, 16);
            this.Fa_key.TabIndex = 17;
            this.Fa_key.Text = "F";
            // 
            // Mi_key
            // 
            this.Mi_key.AutoSize = true;
            this.Mi_key.Font = new System.Drawing.Font("新細明體", 12F);
            this.Mi_key.Location = new System.Drawing.Point(426, 495);
            this.Mi_key.Name = "Mi_key";
            this.Mi_key.Size = new System.Drawing.Size(18, 16);
            this.Mi_key.TabIndex = 16;
            this.Mi_key.Text = "D";
            // 
            // Re_key
            // 
            this.Re_key.AutoSize = true;
            this.Re_key.Font = new System.Drawing.Font("新細明體", 12F);
            this.Re_key.Location = new System.Drawing.Point(347, 495);
            this.Re_key.Name = "Re_key";
            this.Re_key.Size = new System.Drawing.Size(15, 16);
            this.Re_key.TabIndex = 15;
            this.Re_key.Text = "S";
            // 
            // Do_key
            // 
            this.Do_key.AutoSize = true;
            this.Do_key.Font = new System.Drawing.Font("新細明體", 12F);
            this.Do_key.Location = new System.Drawing.Point(257, 495);
            this.Do_key.Name = "Do_key";
            this.Do_key.Size = new System.Drawing.Size(18, 16);
            this.Do_key.TabIndex = 14;
            this.Do_key.Text = "A";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(866, 579);
            this.Controls.Add(this.Si_key);
            this.Controls.Add(this.La_key);
            this.Controls.Add(this.So_key);
            this.Controls.Add(this.Fa_key);
            this.Controls.Add(this.Mi_key);
            this.Controls.Add(this.Re_key);
            this.Controls.Add(this.Do_key);
            this.Controls.Add(this.Autoplay);
            this.Controls.Add(this.Choose);
            this.Controls.Add(this.restart);
            this.Controls.Add(this.StopAuto);
            this.Controls.Add(this.ChangeColor);
            this.Controls.Add(this.Si);
            this.Controls.Add(this.La);
            this.Controls.Add(this.So);
            this.Controls.Add(this.Fa);
            this.Controls.Add(this.Mi);
            this.Controls.Add(this.Re);
            this.Controls.Add(this.Do);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Do;
        private System.Windows.Forms.Button Re;
        private System.Windows.Forms.Button Mi;
        private System.Windows.Forms.Button Fa;
        private System.Windows.Forms.Button So;
        private System.Windows.Forms.Button La;
        private System.Windows.Forms.Button Si;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Button ChangeColor;
        private System.Windows.Forms.Button StopAuto;
        private System.Windows.Forms.Button restart;
        private System.Windows.Forms.ComboBox Choose;
        private System.Windows.Forms.Button Autoplay;
        private System.Windows.Forms.Label Si_key;
        private System.Windows.Forms.Label La_key;
        private System.Windows.Forms.Label So_key;
        private System.Windows.Forms.Label Fa_key;
        private System.Windows.Forms.Label Mi_key;
        private System.Windows.Forms.Label Re_key;
        private System.Windows.Forms.Label Do_key;
    }
}

